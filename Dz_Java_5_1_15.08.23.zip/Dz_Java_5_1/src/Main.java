public class Main {
    public static void main(String[] args) {
        //Создать программу, выводящую на экран ближайшее
        // к 10 из двух чисел, записанных в переменные m и n.
        //Числа могут быть, как целочисленные, так и дробные.
        //Например:
        //ввод: m=10.5, n=10.45
        //вывод: Число 10.45 ближе к 10.
        float num1 = 10.45f;
        float num2 = 10.1f;
        if ((num1-10) > (num2-10)) {
            System.out.println("Ближайшее число к 10: "+num2);
        }
        else {
            System.out.println("Ближайшее число к 10: "+num1);
        }

        
        System.out.println((num1-10) > (num2-10)? num2: num1);







    }
}