import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Необходимо написать программу, которая проверяет пользователя
        // на знание таблицы умножения. Пользователь сам вводит два целых однозначных числа.
        // Программа задаёт вопрос: результат умножения первого числа на второе.
        // Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
        // Если пользователь ответил неправильно, то программа должна показать правильный ответ.
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое число number1: ");
        int number1 = scr.nextInt();
        System.out.println("Введите первое число number2: ");
        int number2 = scr.nextInt();
        System.out.println("результат умножения первого числа на второе? ");
        int number3 = scr.nextInt();
        int number4 = number1*number2;
        if (number3 == number4) {
            System.out.println("Вы ответили правильно");
        }
        else {
            System.out.println("Вы ответили не правильно, правильный ответ: " + number4 );
        }

    }
}