import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Дан (введён или сгенерирован) номер дня недели. Выведите название дня
        //недели. Если номер дня введён некорректно, то выведите соответствующее
        //сообщение и завершите программу
        Random rnd = new Random();
        int dayWeek = rnd.nextInt(1,15);
        //Scanner scr = new Scanner(System.in);
        //System.out.println("Введите первое целое число number: ");
        //int dayWeek = scr.nextInt();
        System.out.println(dayWeek);
        if (dayWeek == 1) {
            System.out.println("Monday");
            return;
        }
        if (dayWeek == 2) {
            System.out.println("Tuesday");
            return;
        }
        if (dayWeek == 3) {
            System.out.println("Wednesday");
            return;
        }
        if (dayWeek == 3) {
            System.out.println("Wednesday");
            return;
        }
        if (dayWeek == 4) {
            System.out.println("Thursday");
            return;
        }
        if (dayWeek == 5) {
            System.out.println("Friday");
            return;
        }
        if (dayWeek == 6) {
            System.out.println("Saturday");
            return;
        }
        if (dayWeek == 7) {
            System.out.println("Sunday");
            return;
        }
        else {
            System.out.println("Не корректное число");
        }


    }
}